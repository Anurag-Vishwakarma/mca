from django.contrib import admin
from news.models import News, Contact, Comment, Category

class NewsModel(admin.ModelAdmin):
    list_display=('news_title','news_desc','news_img')

# Before => admin.site.register(News,NewsModel)
admin.site.register((News, Contact, Comment, Category))
# Register your models here.

admin.site.site_header = "Vindhya Dastak Admin"
admin.site.site_title = "Vindhya Dastak Admin Pannel"
admin.site.index_title = "Welcome to Vindhya Dastak"

