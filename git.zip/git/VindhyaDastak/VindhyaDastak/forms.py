from django import forms

class userForm(forms.Form):
    val = forms.CharField(label="val1")
    val = forms.CharField()