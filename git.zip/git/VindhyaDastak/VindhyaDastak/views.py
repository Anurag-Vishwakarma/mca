from django.http import HttpResponse,HttpResponseRedirect
from django.shortcuts import redirect
from django.shortcuts import render
from .forms import userForm
from news.models import News, Contact, Comment, Category
from django.core.paginator import Paginator
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout

def homePage(request):
    newsData = News.objects.all().order_by("-sno")
    Paginator_variable = Paginator(newsData,5)
    page_number =request.GET.get('page')
    newsDatafinal = Paginator_variable.get_page(page_number)
    popular_news = News.objects.order_by('-views')[:5]
    category = Category.objects.all()
    data = {
        'newsData':newsDatafinal,
        'popular_news':popular_news,
        'category':category
    }
    return render(request,"index.html",data)

def category(request,cat):
    category=Category.objects.get(category_name=cat)
    print(category)
    newsData = News.objects.filter(news_category=category)
    popular_news = News.objects.order_by('-views')[:5]
    data = {'newsData':newsData, 'category':category, 'popular_news':popular_news}
     
    return render(request,"category.html",data)
   
    

def aboutUs(request):
    return render(request,"aboutus.html")

def contactUs(request):
    if request.method=="POST":
        name = request.POST['name']
        email = request.POST['email']
        phone = request.POST['phone']
        content = request.POST['content']
        if len(name)<=2 or len(email)<10 or len(phone)<10 or len(content)<5:
            messages.warning(request,'Oops!! Something went wrong... Please Fill Valid Details.')
        else:
            contact = Contact(name=name, email=email, phone=phone, content=content)
            contact.save()
            messages.success(request,'Great!! Message Sent Successfully.')
    return render(request,"contactus.html")

# def loginPage(request):         
#     if request.method=="GET":
#         output=request.GET.get('output')
#     return render(request,"login.html",{'output': output})

def userForm(request):  
    finalans = 0
    fn = userForm()
    data = {'form':fn}
    try:
        if request.method=="POST":
            num1 = int(request.POST['num1'])
            num2 = int(request.POST['num2'])
            finalans = num1 +num2
            data = {'form':fn, 'output':finalans }
          
            url="/login/?output{}".format(finalans)

            return HttpResponseRedirect(url)
    except:
        pass    
    return render(request,"userForm.html",data) 


def blog(request):
    newsData = News.objects.all();
    if request.method=="GET":
        st=request.GET.get('search_title')
        if st!=None:
            newsData = News.objects.filter(news_title__icontains=st)

    data = {
        'newsData':newsData
    }
    return render(request,'Blog.html',data)

def newsDetails(request,slug):
    newsData = News.objects.order_by('-views')[:5]
    newsDetails = News.objects.filter(slug=slug).first()
    newsDetails.views +=1
    newsDetails.save()

    comment = Comment.objects.filter(blog=newsDetails)
    replies = Comment.objects.filter(blog=newsDetails).exclude(parentComments=None)
    category = Category.objects.all()
    data = {
        'newsData' : newsData,
        'newsDetails' : newsDetails,
        'comment' :comment,
        'user' : request.user,
        'replies' : replies,
        'category':category
    }
       
    return render(request,"Blog.html",data)

def postComment(request):
      if request.method=="POST":
          comments = request.POST.get("comment")
          users = request.user
          postSno = request.POST.get("postSno")
          blog = News.objects.get(slug=postSno)
        
          comment = Comment(comments=comments, users=users, blog=blog)
          comment.save()
          messages.success(request,"you have successfully sent msg:")

      return redirect(f"/newsDetails/{blog.slug}")

def blogContent(request):
    newsData = News.objects.all();
    return render(request,"blog-content.html",newsData)

def search(request):
    if request.method=="GET":
        st=request.GET.get('search_title')
        if st!=None:
            newsData_title = News.objects.filter(news_title__icontains=st)
            newsData_content = News.objects.filter(news_desc__icontains=st)
            newsData = newsData_title.union(newsData_content)
        else:
            messages.warning(request,"OPPS!! Your Searched Data Not Found")  
    data = {
        'newsData':newsData
    }
    return render(request,"search.html",data)

def weather(request):
    return render(request,"weather.html")

def handleSignup(request):
    if request.method=="POST":
        uname = request.POST['uname']
        fname = request.POST['fname']
        lname = request.POST['lname']
        email = request.POST['email']
        password = request.POST['password'] 

        myuser = User.objects.create_user(uname, email, password)
        myuser.first_name = fname
        myuser.last_name = lname
        myuser.save()
        messages.success(request, "your account ccreated successfully")
        return redirect('home')
    else:
        return HttpResponse('404 - Page Not Found ')
    
def handleLogin(request):
    if request.method == "POST":
        loginusername = request.POST['uname']
        loginpassword = request.POST['password']
        
        user = authenticate(username=loginusername, password=loginpassword)

        if user is not None:
            login(request, user)
            messages.success(request, "successfully logged in")
            return redirect('home')
        else:
            messages.success(request,"Invalid Credentials")
            return redirect('about-us')


def handleLogout(request):
    logout(request)
    messages.success(request, "logout")
    
    return redirect('home')