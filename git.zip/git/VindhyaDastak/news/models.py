from django.db import models
from tinymce.models import HTMLField
from autoslug import AutoSlugField
from django.contrib.auth.models import User
from django.utils.timezone import now

class Category(models.Model):
    category_name=models.CharField(max_length=50)

    def __str__(self):
        return self.category_name

class News(models.Model):
    sno = models.AutoField(primary_key=True)
    news_title = models.CharField(max_length=100)
    news_category = models.ForeignKey(Category,on_delete=models.CASCADE, null=True, blank=True)
    news_desc = HTMLField()
    news_img = models.FileField(upload_to="news/", max_length=50, null=True, default=None)
   # news_slug = AutoSlugField(populate_from='news_title',unique=True,null=True,default=None)
    slug = AutoSlugField(populate_from='news_title',unique=True,null=True,default=None )
    views = models.IntegerField(default=0)
    news_time = models.DateTimeField(default=now,null=True, blank=True)

    def __str__(self):
        return self.news_title 

# Create your models here.
class Comment(models.Model):
    sno = models.AutoField(primary_key=True)
    comments = models.TextField()
    users = models.ForeignKey(User,on_delete=models.CASCADE)
    blog = models.ForeignKey(News,on_delete=models.CASCADE)
    parentComments = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True)
    timeDate = models.DateTimeField(default=now)

    def __str__(self):
        return f"{self.comments} Comment by {self.users.username} on {self.blog}"
    


class Contact(models.Model):
    sno = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)
    phone = models.CharField(max_length=13)
    email = models.EmailField(max_length=100)
    content = models.TextField()
    timeStamp =models.DateTimeField(auto_now_add=True,blank=True)

    def __str__(self):
        return 'Messge from ' + self.name + ' - ' + self.email
    
